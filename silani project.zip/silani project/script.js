document.getElementById("clear").onclick = function () {
    document.getElementById("input").value = "";
  };
  document.getElementById((id = "clearOutputButton")).onclick = function () {
    document.getElementById("result").innerText = "";
  };
  function login(event) {
    event.preventDefault();
    var fullName = $("#fullName").val();
    var email = $("#email").val();
    var password = $("#password").val();
  
    if (fullName.length < 3) {
      toastr.error("Type your name correctly!");
    } else if (email === "admin@user.com" && password === "123456") {
      const fullNameParam = encodeURIComponent(fullName); 
      window.location.href = `index.html?fullName=${fullNameParam}`; 
      toastr.success("Welcome, " + fullName + "!");
    } else {
      toastr.error("Invalid email or password.");
    }
  }
  let cities = [
    "Faisalabad",
    "Lahore",
    "Islambad",
    "pindi",
    "Queta",
    "Toba",
    "Sheikhupura",
  ];
  function printCities() {
    document.getElementById("result").innerHTML = " ";
  
    for (i = 0; i < cities.length; i++) {
      let num = i + 1;
      document.getElementById("result").innerHTML +=
        num + ")" + " " + cities[i] + " " + "<br>";
    }
  }
  function addCity() {
    document.getElementById("result").innerHTML = " ";
    let checkCity = document.getElementById("input").value;
    if (!checkCity) {
      alert("Enter city name correctly");
      return;
    }
    CityFirstLetter = checkCity.charAt(0).toUpperCase();
    CityAllLetters = checkCity.slice(1).toLowerCase();
    CityWordInCapitalize = CityFirstLetter + CityAllLetters;
  
    let cityFound = false;
    for (i = 0; i < cities.length; i++) {
      if (cities[i] === CityWordInCapitalize) {
        cityFound = true;
        showToast(
          "Your city " +
            '"' +
            CityWordInCapitalize +
            '"' +
            " is already available in list",
          2000,
          "right",
          "linear-gradient(to right, #f11523, #7a0b23 )"
        );
        return;
      }
    }
    if (cityFound === false) {
      cities.push(CityWordInCapitalize);
  
      showToast(
        '"' +
          CityWordInCapitalize +
          '"' +
          " has been successfully added into the list",
        2000,
        "right",
        "linear-gradient(to right, red, blue)"
      );
      for (i = 0; i < cities.length; i++) {
        num = i + 1;
        document.getElementById("result").innerHTML +=
          num + ")" + " " + cities[i] + "<br>";
      }
    }
  }
  function showToast(
    message,
    duration = 3000,
    position = "top-right",
    backgroundColor = "#333333"
  ) {
    Toastify({
      text: message,
      duration: duration,
      position: position,
      backgroundColor: backgroundColor,
    }).showToast();
  }
  
  
  